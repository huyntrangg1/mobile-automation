# Plugin "QA Pipeline – Export frame"

Xuất frame Figma ra 1 file `.json` (dữ liệu chữ, vị trí, màu, cỡ chữ, constraints + ảnh PNG) để QA Pipeline so UI của app với Figma.
Không cần Figma trả phí, không cần token, không gọi API, không gửi dữ liệu ra ngoài.

## Cài (1 lần)

1. Cài **Figma Desktop** (plugin tự cài chỉ chạy trên bản Desktop, không chạy trên trình duyệt).
2. Mở một file bất kỳ → menu **Plugins → Development → Import plugin from manifest…**
3. Chọn file `figma-plugin/manifest.json` trong thư mục tool.

## Dùng

1. File design của designer chỉ có quyền xem → **Duplicate to your drafts** (menu tên file). Plugin cần quyền sửa nên chạy trên bản copy.
2. Kiểm tra tab **Prototype** (panel phải): các mũi tên nối nút → frame đích (On tap → Navigate to, kiểu animation, thời lượng). Có prototype thì tool gợi ý bước Animation và tính phủ chuyển cảnh.
3. Frame trạng thái (loading, lỗi, rỗng…) đặt tên có dấu `/`, vd `Login / Error`, hoặc dùng variant.
4. Chọn các frame cần so — **cả frame nguồn lẫn frame đích** của chuyển cảnh (chọn cả Section cũng được) → **Plugins → Development → QA Pipeline – Export frame** → **Xuất file .json**.
