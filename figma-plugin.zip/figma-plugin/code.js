// QA Pipeline – Export frame: các frame đang chọn → 1 file JSON (cây node cùng dạng REST API của Figma + ảnh PNG)
// để tool so UI với Figma không cần token / API. Không gửi gì ra mạng: file tải về máy qua cửa sổ plugin (ui.html).
//
// Dạng file: { tool: 'qa-pipeline-figma-export', version: 2 (thêm reactions / variant / strokes / effects), file, page, exportedAt, frames: [{ id, name, scale, width, height, node, png (base64) }] }

// Plugin API → tên của REST API (tool đọc theo REST)
const H = { MIN: 'LEFT', MAX: 'RIGHT', CENTER: 'CENTER', STRETCH: 'LEFT_RIGHT', SCALE: 'SCALE' };
const V = { MIN: 'TOP', MAX: 'BOTTOM', CENTER: 'CENTER', STRETCH: 'TOP_BOTTOM', SCALE: 'SCALE' };
const isMixed = (v) => typeof figma !== 'undefined' && v === figma.mixed;

function paints(list) {
  if (!Array.isArray(list)) return [];
  return list.map((p) => {
    const out = { type: p.type, visible: p.visible !== false, opacity: p.opacity == null ? 1 : p.opacity };
    if (p.type === 'SOLID') out.color = { r: p.color.r, g: p.color.g, b: p.color.b, a: 1 };
    return out;
  });
}

// Chữ nhiều kiểu (mixed) → lấy kiểu của ký tự đầu
function textProps(n) {
  const first = (key, getter) => {
    const v = n[key];
    if (!isMixed(v)) return v;
    try { return n[getter](0, 1); } catch (e) { return null; }
  };
  const font = first('fontName', 'getRangeFontName');
  const fills = first('fills', 'getRangeFills');
  const weight = first('fontWeight', 'getRangeFontWeight');
  return {
    characters: n.characters,
    fills: paints(fills),
    style: {
      fontSize: first('fontSize', 'getRangeFontSize'),
      fontFamily: font ? font.family : null,
      fontStyle: font ? font.style : null,
      fontWeight: weight == null ? null : weight,
      textAlignHorizontal: n.textAlignHorizontal,
      textCase: first('textCase', 'getRangeTextCase') || 'ORIGINAL',
    },
  };
}

// Prototype: bấm / chạm → sang frame nào, kiểu chuyển, thời gian (ms), easing. API mới: reactions[].actions[], cũ: reactions[].action
const EASING = (e) => (e && e.type) || null;
function reactions(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const r of list) {
    const acts = Array.isArray(r.actions) ? r.actions : r.action ? [r.action] : [];
    for (const a of acts) {
      if (!a || a.type !== 'NODE' || !a.destinationId) continue;
      const t = a.transition || null;
      out.push({
        trigger: (r.trigger && r.trigger.type) || null,
        destinationId: a.destinationId,
        navigation: a.navigation || 'NAVIGATE',
        transition: t ? { type: t.type, direction: t.direction || null, duration: Math.round((t.duration || 0) * 1000), easing: EASING(t.easing) } : null,
      });
    }
  }
  return out;
}

function effects(list) {
  if (!Array.isArray(list)) return [];
  return list.filter((e) => e.visible !== false).map((e) => ({
    type: e.type, radius: e.radius || 0, offset: e.offset ? { x: e.offset.x, y: e.offset.y } : null,
    color: e.color ? { r: e.color.r, g: e.color.g, b: e.color.b, a: e.color.a } : null,
  }));
}

// Variant: frame là 1 variant của component set ("State=Error") hoặc instance đang dùng variant nào
function variants(n) {
  try {
    if (n.variantProperties) return Object.assign({}, n.variantProperties);
  } catch (e) { /* node không phải variant */ }
  try {
    if (n.componentProperties) {
      const out = {};
      for (const k of Object.keys(n.componentProperties)) {
        const p = n.componentProperties[k];
        if (p && p.type === 'VARIANT') out[k.split('#')[0]] = p.value;
      }
      return Object.keys(out).length ? out : null;
    }
  } catch (e) { /* bỏ qua */ }
  return null;
}

function serialize(n) {
  const b = n.absoluteBoundingBox;
  const out = {
    id: n.id,
    name: n.name,
    type: n.type,
    visible: n.visible !== false,
    opacity: n.opacity == null ? 1 : n.opacity,
    absoluteBoundingBox: b ? { x: b.x, y: b.y, width: b.width, height: b.height } : null,
  };
  if (n.constraints) out.constraints = { horizontal: H[n.constraints.horizontal] || 'LEFT', vertical: V[n.constraints.vertical] || 'TOP' };
  if (n.layoutMode && n.layoutMode !== 'NONE') out.layoutMode = n.layoutMode;
  if (n.layoutAlign) out.layoutAlign = n.layoutAlign;
  if (n.layoutPositioning) out.layoutPositioning = n.layoutPositioning;
  if (typeof n.cornerRadius === 'number') out.cornerRadius = n.cornerRadius;
  else if (typeof n.topLeftRadius === 'number') out.cornerRadius = n.topLeftRadius;
  const rx = reactions(n.reactions);
  if (rx.length) out.reactions = rx;
  const v = variants(n);
  if (v) out.variant = v;
  if (Array.isArray(n.strokes) && n.strokes.length) { out.strokes = paints(n.strokes); if (typeof n.strokeWeight === 'number') out.strokeWeight = n.strokeWeight; }
  const fx = effects(n.effects);
  if (fx.length) out.effects = fx;
  if (n.type === 'TEXT') Object.assign(out, textProps(n));
  else if ('fills' in n) out.fills = paints(isMixed(n.fills) ? [] : n.fills);
  if ('children' in n && n.children) out.children = n.children.map(serialize);
  return out;
}

const b64 = (bytes) => (typeof figma !== 'undefined' && figma.base64Encode ? figma.base64Encode(bytes) : Buffer.from(bytes).toString('base64'));

async function exportFrames(nodes, scale) {
  const frames = [];
  for (const n of nodes) {
    const bytes = await n.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: scale } });
    frames.push({ id: n.id, name: n.name, scale, width: n.width, height: n.height, node: serialize(n), png: b64(bytes) });
  }
  return frames;
}

const pickable = (n) => ['FRAME', 'COMPONENT', 'INSTANCE', 'SECTION'].includes(n.type);
// Section → các frame bên trong (chọn cả section 1 lần)
const expand = (sel) => sel.flatMap((n) => (n.type === 'SECTION' ? n.children.filter((c) => c.type !== 'SECTION' && pickable(c)) : pickable(n) ? [n] : []));

if (typeof figma !== 'undefined') {
  figma.showUI(__html__, { width: 320, height: 300 });
  const report = () => {
    const frames = expand(figma.currentPage.selection);
    figma.ui.postMessage({ type: 'selection', names: frames.map((f) => f.name) });
  };
  report();
  figma.on('selectionchange', report);
  figma.ui.onmessage = async (msg) => {
    if (msg.type !== 'export') return;
    const nodes = expand(figma.currentPage.selection);
    if (!nodes.length) { figma.ui.postMessage({ type: 'error', text: 'Chọn ít nhất 1 frame (màn) trước.' }); return; }
    try {
      figma.ui.postMessage({ type: 'busy', text: `Đang xuất ${nodes.length} frame…` });
      const frames = await exportFrames(nodes, msg.scale || 3);
      const data = { tool: 'qa-pipeline-figma-export', version: 2, file: figma.root.name, page: figma.currentPage.name, exportedAt: new Date().toISOString(), frames };
      figma.ui.postMessage({ type: 'done', name: `${figma.root.name}-${frames.length}-frame.json`.replace(/[\\/:*?"<>|]+/g, '-'), json: JSON.stringify(data) });
    } catch (e) {
      figma.ui.postMessage({ type: 'error', text: `Xuất lỗi: ${e.message || e}` });
    }
  };
} else if (typeof module !== 'undefined') {
  // Chạy trong Node (test): dùng hàm chuyển đổi
  module.exports = { serialize, exportFrames, expand, reactions };
}
